# 121. Best Time to Buy and Sell Stock

Property: September 15, 2022

# Question

原文：

You are given an array `prices` where `prices[i]` is the price of a given stock on the `ith` day.

You want to maximize your profit by choosing a **single day** to buy one stock and choosing a **different day in the future** to sell that stock.

Return *the maximum profit you can achieve from this transaction*. If you cannot achieve any profit, return `0`.

我的理解：

翻譯：

自評翻譯正確性：

- Word Memory：

# Code

```cpp
class Solution {
public:
    int maxProfit(vector<int>& prices) {
        int min=0,i,ca=0;//min往前的最小節點 ca營利
        
        min=prices[0];//先把第一個節點當作最小節點
        
        for(i=1;i<prices.size();i++){
            
            if((prices[i]-min)>ca){//營利如果大於之前的最高營利就更新 一開始的預設是 ca 是 0
                ca=prices[i]-min;
            }
            
            if(prices[i]<min){//更新目前的最小節點 i繼續往後算就都會是在這個節點之後
                min=prices[i];
            }
            
        }
        return ca;
    }
};
```

> 思路：先記錄第一個節點min當最小節點，後續只要遇到更小的節點就更新，因為i只會一直往後，現在能抓到的節點都比後面的位置靠前，ca的部份就記錄目前節點減去前方最小的節點的值，如果比有大於當前ca的就更新。
> 

![Untitled](121%20Best%20Time%20to%20Buy%20and%20Sell%20Stock%201a12ca27974448d594564b9493e003db/Untitled.png)

## 優良code參考

```cpp

```

> 思路：
>