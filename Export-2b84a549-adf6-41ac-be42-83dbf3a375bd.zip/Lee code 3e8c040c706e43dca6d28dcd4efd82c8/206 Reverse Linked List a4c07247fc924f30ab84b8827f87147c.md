# 206. Reverse Linked List

Property: August 30, 2022

# Question

原文：

Given the `head`of a singly linked list, reverse the list, and return *the reversed list.*

我的理解：

給一個linked list 將其整個反過來串接

Ex：input 1→2→3，outout：3→2→1

翻譯：

自評翻譯正確性：100

- Word Memory：reverse 倒轉、撤銷

# Code

```cpp
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode() : val(0), next(nullptr) {}
 *     ListNode(int x) : val(x), next(nullptr) {}
 *     ListNode(int x, ListNode *next) : val(x), next(next) {}
 * };
 */
class Solution {
public:
    ListNode* reverseList(ListNode* head) {
        ListNode * tra;
        ListNode * tratemp;
        ListNode * traback;
        if(head==NULL){
            return NULL;
        }
        else if(head->next==NULL){
            return head;
        }
        
        
        tra=head;
        
        traback=tra;
        tra=tra->next;
        traback->next=NULL;
        tratemp=tra;
        tra=tra->next;
        if(tra==NULL){
            tratemp->next=traback;
            return tratemp;
        }
        
        
        while(tra->next!=NULL){
            tratemp->next=traback;
            traback=tratemp;
            tratemp=tra;
            tra=tra->next;
        }
        tratemp->next=traback;
        tra->next=tratemp;
        return tra;
        
    }
};
```

> 思路：以三個節點為一組，tra指向最後端，tratemp指向居中，traback指向最前頭，開始循環4步驟：１tratemp->next=traback;居中指向前方，前方的節點則指向更前方達到反轉的目標２ traback=tratemp;最前方指標往前移（成為新的最前方）３tratemp=tra;居中指標往前移（成為新的居中）４tra=tra->next;最後方往後移（成為新的最後），重複執行居中的指標就會ㄧ直往前指而非往後。最後while執行完之後 tratemp->next=traback;  tra->next=tratemp; 用意是在於當tra→next指向NULL時while就會結束，但此時的tratemp、tra指向的節點尚未加進前方的linkedlist，這兩句就是將這兩個節點加進list
> 

### while過程：

![Untitled](206%20Reverse%20Linked%20List%20a4c07247fc924f30ab84b8827f87147c/Untitled.png)

### 特殊狀況過濾：

![Untitled](206%20Reverse%20Linked%20List%20a4c07247fc924f30ab84b8827f87147c/Untitled%201.png)

![Untitled](206%20Reverse%20Linked%20List%20a4c07247fc924f30ab84b8827f87147c/Untitled%202.png)

## 優良code參考

```cpp
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode() : val(0), next(nullptr) {}
 *     ListNode(int x) : val(x), next(nullptr) {}
 *     ListNode(int x, ListNode *next) : val(x), next(next) {}
 * };
 */
class Solution {
public:
    ListNode* reverseList(ListNode* head) {
        ListNode *nextNode, *prevNode = NULL;
        while (head) {
            nextNode = head->next;
            head->next = prevNode;
            prevNode = head;
            head = nextNode;
        }
        return prevNode;
    }
};
```

> 思路：
>