# 766. Toeplitz Matrix

Property: October 31, 2022

# Question

原文：

![Untitled](766%20Toeplitz%20Matrix%20b25a69725f8b4f279bf79caabba51a84/Untitled.png)

我的理解：

給定一矩陣，確認矩陣是否是*Toeplitz矩陣*，也就是左上到右下的斜線都是相同

翻譯：

自評翻譯正確性：

- Word Memory：

# Code

```cpp
class Solution {
public:
    bool isToeplitzMatrix(vector<vector<int>>& matrix) {
        int i=0,j=0;
        int high = matrix.size()-1;
        int length = matrix[0].size()-1;
        int check_num=0;
        vector<int>com1;
        vector<int>com2;
        
        for( i=0;i<high;i++ ){
            for( j=0;j<length;j++ ){
                com1.push_back(matrix[i][j]);
                com2.push_back(matrix[i+1][j+1]);
            }
            if(com1!=com2){
                check_num=1;
            }
        }
        
        if(check_num==1)
            return false;
        else
            return true;
    }
};
```

> 思路：上一行的除了最後一個元素會跟下一行的除了第一個元素 相同，思路如下圖
> 

![74F336AC-DC21-428D-8F79-05177750B14D.jpeg](766%20Toeplitz%20Matrix%20b25a69725f8b4f279bf79caabba51a84/74F336AC-DC21-428D-8F79-05177750B14D.jpeg)

![Untitled](766%20Toeplitz%20Matrix%20b25a69725f8b4f279bf79caabba51a84/Untitled%201.png)

## 優良code參考

```cpp
static bool isToeplitzMatrix(const vector<vector<int>>& matrix) {
        const int rows = matrix.size();
        const int cols = matrix[0].size();
        for (int r = 1; r < rows; ++r)
            for (int c = 1; c < cols; ++c)
                if (matrix[r][c] != matrix[r - 1][c - 1]) return false;
        
        return true;
    }
```

> 思路：逐個向自身 左上 的元素比較
>