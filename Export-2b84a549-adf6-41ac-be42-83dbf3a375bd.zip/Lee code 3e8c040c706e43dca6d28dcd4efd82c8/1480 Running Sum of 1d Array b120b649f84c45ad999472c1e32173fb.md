# 1480. Running Sum of 1d Array

Property: August 11, 2022

# Question

原文：

Given an array `nums`. We define a running sum of an array as `runningSum[i] = sum(nums[0]…nums[i])`.

Return the running sum of `nums`.

我的理解：

給一個陣列nums，return runningSum，runningSum[i]的值是nums[0]~nums[i]所有數之和

翻譯：

给定一个数组nums。我们定义一个数组的运行和为runningSum[i] = sum(nums[0]...nums[i])。

返回nums的运行总和。

自評翻譯正確性：10%

- Word Memory：注意看完整段意思

# Code

```cpp
class Solution {
public:
    vector<int> runningSum(vector<int>& nums) {
        int i;
        for(i=1;i<nums.size();i++){
            nums[i]=nums[i]+nums[i-1];
        }
        return nums;
    }
};
```

![Untitled](1480%20Running%20Sum%20of%201d%20Array%20b120b649f84c45ad999472c1e32173fb/Untitled.png)