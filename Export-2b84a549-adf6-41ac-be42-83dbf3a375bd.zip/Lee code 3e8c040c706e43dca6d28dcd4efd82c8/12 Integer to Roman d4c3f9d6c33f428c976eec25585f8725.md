# 12. Integer to Roman

Property: October 20, 2022
Tags: medium

# Question

原文：

![Untitled](12%20Integer%20to%20Roman%20d4c3f9d6c33f428c976eec25585f8725/Untitled.png)

我的理解：

給一數字num，轉換成羅馬數字寫法，下方有提供轉換規則跟特殊例外，例如各自母分別表示多少的數值和每逢4、9有特殊規定

翻譯：

例如，2在罗马数字中被写成II，只是两个1相加。12写成XII，就是简单的X+II。27写成XXVII，也就是XX+V+II。

罗马数字通常从左到右从大到小书写。然而，4的数字不是IIII。相反，四的数字被写成四。因为一在五的前面，我们把它减去就成了四。同样的原则也适用于数字9，它被写成IX。有六种情况用到了减法。

I可以放在V（5）和X（10）之前，组成4和9。
X可以放在L（50）和C（100）之前，组成40和90。
C可以放在D(500)和M(1000)之前，组成400和900。
给出一个整数，把它转换成罗马数字。

自評翻譯正確性：

- Word Memory：

# Code

```cpp
class Solution {
public:
    string intToRoman(int num) {
        int th=0,hu=0,te=0,di=0;//用來記錄千、百、十、個位數的值
        string ans="";
        th=num/1000;
        num=num%1000;
        
        hu=num/100;
        num=num%100;
        
        te=num/10;
        di=num%10;
        ans+=intDividToRoman(th,"M");
        ans+=intDividToRoman(hu,"CDM");
        ans+=intDividToRoman(te,"XLC");
        ans+=intDividToRoman(di,"IVX");
        return ans;
    }
		//依照命名規則撰寫intDividToRoman
    string intDividToRoman(int temp,string tra){
        if(temp==9){
            string tempstr="";
            tempstr.push_back(tra[0]);
            tempstr.push_back(tra[2]);
            return tempstr;
        }
        else if(temp==4){
            string tempstr="";
            tempstr.push_back(tra[0]);
            tempstr.push_back(tra[1]);
            return tempstr;
        }
        else if(temp==5){
            string tempstr="";
            tempstr.push_back(tra[1]);
            return tempstr;
        }
        else if(8>=temp & 6<=temp){
            string tempstr="";
            tempstr.push_back(tra[1]);
            while(temp>5){
                tempstr.push_back(tra[0]);
                temp--;
            }
            return tempstr;
        }
        else if(3>=temp & 1<=temp){
            string tempstr="";
            while(temp>0){
                tempstr.push_back(tra[0]);
                temp--;
            }
            return tempstr;
        }
        else
            return "";
    }
};
```

> 思路：最大數字只到3999，各個位數的換算方法其實一樣，只是代換的英文字母不同，但實質上一個位數就是三個字母的相互組合，例如：百位數，就是M1000 D500 C100，這三個字母拼湊，因此intDividToRoman()只要帶入各位數的值以及該為數相對應的三個字母，加上轉換規則就可以轉換出該位數對應的羅馬數字
> 
> - 規則一：如果temp=9，詳見code
> - 規則二：如果temp=4，詳見code
> - 規則三：如果temp=5，詳見code
> - 規則四：如果8≤temp≤6，詳見code
> - 規則五：如果3≤temp≤1，詳見code
> - 如果以上都不等於：理應為temp=0，return “”

![Untitled](12%20Integer%20to%20Roman%20d4c3f9d6c33f428c976eec25585f8725/Untitled%201.png)

## 優良code參考

```cpp

```

> 思路：
>