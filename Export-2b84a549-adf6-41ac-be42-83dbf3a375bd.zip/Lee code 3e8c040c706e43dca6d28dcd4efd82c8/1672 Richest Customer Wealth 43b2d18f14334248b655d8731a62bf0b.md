# 1672 Richest Customer Wealth

Property: August 10, 2022

# Question

原文：You are given an `m x n` integer grid `accounts` where `accounts[i][j]` is the amount of money the `ith` customer has in the `jth` bank. Return *the **wealth** that the richest customer has.*

A customer's **wealth** is the amount of money they have in all their bank accounts. The richest customer is the customer that has the maximum **wealth**.

我的理解：

會給我一個 m＊n 的二維陣列 account，account[i][j]，i表示第一位客人，j表示該客人在不同銀行所存的錢，目標是找出各行的存款餘額加起來最多的人以及他的總存款是多少

翻譯：

给你一个m x n的整数网格账户，其中账户[i][j]是第i个客户在第j个银行的资金量。返回最富有的客户所拥有的财富。

一个客户的财富是他们在所有银行账户中的资金数额。最富有的客户是拥有最大财富的客户。

自評翻譯正確性：100%

- Word Memory：
    - wealth財富

# Code

accounts.size() #拿到行數 直的數有幾個

accounts[i].size() #拿到列數 i行橫的數有幾個

```cpp
class Solution {
public:
    int maximumWealth(vector<vector<int>>& accounts) {
        int max=0;
        int temp,i,j;
        for(i=0;i<accounts.size();i++){
            temp=0;
            for(j=0;j<accounts[i].size();j++)
                temp=temp+accounts[i][j];
            if(temp>max){
                max=temp;
            }
        }
        return max;
    }
};
```

![Untitled](1672%20Richest%20Customer%20Wealth%2043b2d18f14334248b655d8731a62bf0b/Untitled.png)