# 2131. Longest Palindrome by Concatenating Two Letter Words

Property: November 3, 2022
Tags: medium, unordered_map

# Question

原文：

You are given an array of strings `words`. Each element of `words` consists of **two** lowercase English letters.

Create the **longest possible palindrome** by selecting some elements from `words` and concatenating them in **any order**. Each element can be selected **at most once**.

Return *the **length** of the longest palindrome that you can create*. If it is impossible to create any palindrome, return `0`.

A **palindrome** is a string that reads the same forward and backward.

我的理解：

翻譯：

自評翻譯正確性：

- Word Memory：

# Code

```cpp
class Solution {
public:
    int longestPalindrome(vector<string>& words) {
        int i=0,j=0;
        int ans_len=0;
        string temp="";
        unordered_map<string,int>re;
        
        for( j=0;j<words.size();j++ ){
            temp=words[j];
            reverse(temp.begin(),temp.end());
            
            //將元素放進hash table裡面，計算出現次數
            if(re.count(words[j])==0){
                re[words[j]]=1;
            }
            else{
                re[words[j]]++;
            }
            
            //有兩種元素，兩字元相同XX，兩字元不同XY，分開處理
            //XY，如果自身的reverse出現次數 "大於等於" 自身，表示出現回文可以放進 palindrome 字串 =>答案字串長度+4
            if(words[j][0]!=words[j][1]){
                if(re.count(temp)!=0){
                    if(re[temp]-re[words[j]]>=0){
                        ans_len=ans_len+4;
                    }
                }
            }
            
            //XX，因為自身和reverse相同，如果出現次數為偶數就是出現回文可以放進 palindrome 字串 =>答案字串長度+4
            else if(words[j][0]==words[j][1]){
                if(re[words[j]]%2==0){
                    ans_len=ans_len+4;
                }
            }
        }
        //檢查 hash table中 XX 類型的元素有沒有出現次數是奇數的
        //如果有，該元素可以放一個在字串中心，但也只能放一個所以找到一個就break
        for( i=0;i<words.size();i++ ){
            if(words[i][0]==words[i][1] && re[words[i]]%2==1){
                ans_len=ans_len+2;
                break;
            }
        }
        
        return ans_len;
    }
};
```

> 思路：
> 
> - 將所有出現元素放進hash table計算出現次數，並把出現的元素分為兩種類型，兩字元相同XX，兩字元不同XY
> - XY⇒如果自身的reverse出現次數 "大於等於" 自身，表示出現回文可以放進 palindrome 字串 =>答案字串長度+4
> - XX⇒因為自身和reverse相同，如果出現次數為偶數就是出現回文可以放進 palindrome 字串 =>答案字串長度+4
> - 最後再檢查是否有XX類型的元素出現次數為奇數，該元素可以放一個在字串中心，但也只能放一個所以找到一個就break

## 優良code參考

```cpp

```

> 思路：
>