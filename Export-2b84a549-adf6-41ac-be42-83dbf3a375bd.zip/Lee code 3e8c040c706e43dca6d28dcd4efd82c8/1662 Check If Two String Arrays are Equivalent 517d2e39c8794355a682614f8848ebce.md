# 1662. Check If Two String Arrays are Equivalent

Property: October 25, 2022

# Question

原文：

Given two string arrays `word1` and `word2`, return **`true` *if the two arrays **represent** the same string, and* `false` *otherwise.*

A string is **represented** by an array if the array elements concatenated **in order** forms the string.

我的理解：

翻譯：

自評翻譯正確性：100

- Word Memory：

# Code

```cpp
class Solution {
public:
    bool arrayStringsAreEqual(vector<string>& word1, vector<string>& word2) {
        string str1="",str2="";
        int i=0,j=0;
        for(i=0;i<word1.size();i++){
            str1+=word1[i];
        }
        for(j=0;j<word2.size();j++){
            str2+=word2[j];
        }
        if(str1==str2){
            return true;
        }
        else{
            return false;
        }
    }
};
```

> 思路：兩個陣列各自將內容物合成字串，相比對，長一樣就true，反之false
> 

![Untitled](1662%20Check%20If%20Two%20String%20Arrays%20are%20Equivalent%20517d2e39c8794355a682614f8848ebce/Untitled.png)

## 優良code參考

```cpp

```

> 思路：
>