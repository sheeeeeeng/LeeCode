# 876. Middle of the Linked List

Property: September 12, 2022

# Question

原文：

Given the `head` of a singly linked list, return *the middle node of the linked list*.

If there are two middle nodes, return **the second middle** node.

我的理解：

給定一串鏈結陣列，返回中間的node的數值，如果node個數是偶數個有返回後面那個node數值

翻譯：

给出一个单链表的 "头"，返回*链表的中间节点*。

如果有两个中间节点，返回**第二个中间**节点。

自評翻譯正確性：70% (要返回的是包含該node與其後方的整串)

- Word Memory：

# Code

```cpp
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode() : val(0), next(nullptr) {}
 *     ListNode(int x) : val(x), next(nullptr) {}
 *     ListNode(int x, ListNode *next) : val(x), next(next) {}
 * };
 */
class Solution {
public:
    ListNode* middleNode(ListNode* head) {
        ListNode * pre=head;
        ListNode * pro=head;
        int i=0,j=0;
        if(head->next==NULL){
            return head;
        }
        while(pre!=NULL){
            pre=pre->next;
            i++;
        }
        
        i=i/2;
        
        while(j<i){
            pro=pro->next;
            j++;
        }
        return pro;
    }
};
```

> 思路：先開一個 pre 去遍歷抓整個list長度，紀錄為i，然後i除2，之後再用一個 pro 遍歷並用 j 記步，一直到j==i就是一半的位置
> 

![Untitled](876%20Middle%20of%20the%20Linked%20List%20ae06981807a047d98208b800e59eca5d/Untitled.png)

## 優良code參考

```cpp
class Solution {
public:
    ListNode* middleNode(ListNode* head) {
        ListNode *slow = head, *fast = head;
        while (fast && fast->next) {
            slow = slow->next;
            fast = fast->next->next;
        }
        return slow;
    }
};
```

> 思路：分成兩個pointer下去跑，slow & fast，fast跑的是slow的兩倍快，所以如果fast已經抵達終點或者說已經不能再往下跑了停止時，slow跑的剛好是fast的一半，也就剛好是在一半的位置。(great solution)
>