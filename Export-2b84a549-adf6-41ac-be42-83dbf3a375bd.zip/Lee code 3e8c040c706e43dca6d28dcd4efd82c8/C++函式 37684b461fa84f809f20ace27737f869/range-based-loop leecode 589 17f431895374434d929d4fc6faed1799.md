# range-based-loop leecode 589

[https://www.geeksforgeeks.org/range-based-loop-c/](https://www.geeksforgeeks.org/range-based-loop-c/)

![Untitled](range-based-loop%20leecode%20589%2017f431895374434d929d4fc6faed1799/Untitled.png)

該寫法類似 python 裡的 for i in range(n.j)，auto的部份會自動將 i 型別設定成符合後方集合內物件的型別（這邊集合是MAP），然後 i 開始遍歷 MAP內的所有子物件，遍歷完畢後 for 迴圈結束