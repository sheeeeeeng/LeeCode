# unordered map<type,type>name

基本上是利用hash table的概念，所以索引的key是可以不是0開始的正整數，可以是字串、字符等等，因為key值再做一次hash對應到它們各自的index，再透過index去查詢bucket裡面的值

範例：unordered_map<char,int>m1;

上方這個宣告在key設定時就可以直接利用char型別的元素進行設定，對應的值則是使用int型態

例如：m1[’a’]=10

在查詢的時候

cout<<m1[’a’];

輸出就會是10

![Untitled](unordered%20map%20type,type%20name%200a6b34131ff74774aa8befd746355f51/Untitled.png)