# 54. Spiral Matrix

Property: October 16, 2022
Tags: medium

# Question

原文：

Given an `m x n matrix`, return *all elements of the* `matrix`*in spiral order*.

![Untitled](54%20Spiral%20Matrix%2038ee3176f37e4c15a11da3c392c3fc2a/Untitled.png)

我的理解：

就是按照螺旋順序輸出陣列

翻譯：

自評翻譯正確性：100

- Word Memory：

# Code

```cpp
class Solution {
public:
    vector<int> spiralOrder(vector<vector<int>>& matrix) {
        int R_move=1,B_move=0,L_move=0,T_move=0;//record move type
        int R_side=matrix[0].size()-1,B_side=matrix.size()-1,L_side=0,T_side=0;//record side value
        int step=matrix[0].size()*matrix.size();//count how many step
        int temp=0;
        vector<int> ans;
        while(temp<step){
            if(R_move==1){
                for(int i=L_side;i<=R_side;i++){//R_move Left->Right T_side++
                    ans.push_back(matrix[T_side][i]);
                    temp++;
                }
                R_move=0;
                B_move=1;
                T_side++;
            }
            else if(B_move==1){
                for(int i=T_side;i<=B_side;i++){//B_move Top->Bottom R_side--
                    ans.push_back(matrix[i][R_side]);
                    temp++;
                }
                B_move=0;
                L_move=1;
                R_side--;
            }
            else if(L_move==1){
                for(int i=R_side;i>=L_side;i--){//L_move Right->Left B_side--
                    ans.push_back(matrix[B_side][i]);
                    temp++;
                }
                L_move=0;
                T_move=1;
                B_side--;
            }
            else if(T_move==1){
                for(int i=B_side;i>=T_side;i--){//T_move Bottom->Top L_side++
                    ans.push_back(matrix[i][L_side]);
                    temp++;
                }
                T_move=0;
                R_move=1;
                L_side++;
            }
        }
        return ans;
    }
};
```

> 思路：螺旋主要分為四種移動方式往右、往下、往左、往上，並且會依次循環
> 
> - 往右：以left side value為起點，right side value為終點，走過一上橫列Top往內縮
> - 往下：以Top side value為起點，Bottom side value為終點，走過一右直列Right往內縮
> - 往左：以right side value為起點，left side value為終點，走過一下橫列bottom往內縮
> - 往上：以bottom side value為起點，top side value為終點，走過一左直列left往內縮
> 
> 並且每動一步temp++，當temp==元素總數時表示已經走完matrix
> 

![Untitled](54%20Spiral%20Matrix%2038ee3176f37e4c15a11da3c392c3fc2a/Untitled%201.png)

## 優良code參考

```cpp

```

> 思路：
>