# 219. Contains Duplicate II

Property: October 21, 2022
Tags: unordered_map

# Question

原文：

Given an integer array `nums`
 and an integer `k`
, return `true`
 if there are two **distinct indices**
 `i`
 and `j`
 in the array such that `nums[i] == nums[j]`
 and `abs(i - j) <= k`
.

![Untitled](219%20Contains%20Duplicate%20II%20ee11bdef9df748bab8d8e79741b3c10a/Untitled.png)

我的理解：

給定一個int vector nums和int k，假如nums中有重複的數字並且重複數字之間的距離小於等於k，return true，如果沒有符合條件return false

翻譯：

自評翻譯正確性：100

- Word Memory：

# Code

```cpp
class Solution {
public:
    bool containsNearbyDuplicate(vector<int>& nums, int k) {
        int i=0;
        unordered_map<int,int>temp;
        
        for( i=0 ; i<nums.size() ; i++ ){
            if(temp.count(nums[i]) == 1){
                if(abs(i-temp[nums[i]]) <= k){
                    return true;
                }
            }
            temp[nums[i]]=i;
        }
        return false;
    }
};
```

> 思路：
> 
> - 使用hashmap 這邊變數名稱為 temp
> - 把 nums 裡的數值當作 temp 的索引值，nums 中的索引則當作 temp 的數值
> - if(temp.count(nums[i])) 假如 temp 中存在 當前要尋找的 數值，表示之前已經出現過
>     - 比對索引值，兩次出現在 nums 中的索引值相減取絕對值，如果小於等於 k return true
> - 假如不存在 則將目前的數值加入 temp 中
> - 重複上述直到所有 nums 數值都被加入 temp
> - 全部比對失敗 return false

![Untitled](219%20Contains%20Duplicate%20II%20ee11bdef9df748bab8d8e79741b3c10a/Untitled%201.png)

## 優良code參考

```cpp

```

> 思路：
>